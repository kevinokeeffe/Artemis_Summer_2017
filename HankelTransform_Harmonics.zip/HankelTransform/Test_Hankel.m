%% Harmonic rings caused by long trajectory phase modulation
% Taken from Catoire et al. PRA 94, 063401 (2016)
% Only for fixed wavelength
% needs ht.mat function from Mathworks file exchange
% 1. Hows does alpha change the far-field transverse profile?
% 2. Dipole phase modulation at the source looks like a grating
% 3. Two target, Hankel transform propagated single harmonic frequency

%% 1. Hows does alpha change the far-field transverse profile?
L = 1E3;
x = linspace(0,500,L);
dx = mean(diff(x));

w = 30;
EIR = exp(-x.^2/w^2);
qeff = 3;
I_max = 1;
alp_val = [1 4 12 24];
lam = 0.8/21;
k_vec = 2*pi/lam;
Z = 1E6;
X = 0:2*pi/(L*dx):2*pi/dx-2*pi/(L*dx);
X = Z*X/k_vec;

for i =alp_val
[Hank,kern] = ht(EIR.^qeff.*exp(1i*i*I_max*abs(EIR).^2));
plot(X/1E3,abs(Hank).^2/max(abs(Hank).^2))
hold on
end
hold off
legend('\alpha = 1','\alpha = 4','\alpha = 12','\alpha = 24','location','northeast')
xlabel('mm')
ylabel('Intensity (norm.)')
xlim([0 30])
title('I_{max} = 1\times10^{14}, q = 21, q_{eff} = 3')
set(gca,'linewidth',4)

%% 2. Dipole phase modulation at the source looks like a grating
plot(x,cos(alpha_long*I_max*abs(EIR).^2))
hold on
plot(x,cos(alpha_short*I_max*abs(EIR).^2))
plot(x,abs(EIR.^qeff).^2,':')
hold off
xlim([0 35])
xlabel('\mum')
ylabel('Cos[\alpha_i\timesI_0(r)]')
legend('Long','Short','Harmonic Source Intensity','location','southeast')
set(gca,'linewidth',4)
%% 3. Two target, Hankel transform propagated single harmonic frequency
%  plotted in 2-D half space (r,z)
clear all
tic
L = 0.5E3; % max radial coordinate in microns
x = linspace(0,750,L);
dx = mean(diff(x)); % r step size

w = 20; % IR driver waist
EIR = exp(-x.^2/w^2); % IR driver transverse FIELD 
lam_0 = 0.8; % driver wavelength 

q = 21; % order
lam = lam_0/q; % harmonic wavelenth

qeff = 3; % effective nonlinearity
alpha_long = 24; % long trajectory alpha (10^-14 cm^2/W)
alpha_short = 4; % short trajectory alpha
I_max = 1; % peak intensity  10^14 W/cm^-2

zr = pi*w^2/lam_0;
z = 2*linspace(-zr,0,200); % span of z locations
I_z = 1./(1+(z./zr).^2); % Fundamental intensity variation with z
CEP = -atan(z/zr); % Gouy phase
k_vec = 2*pi/lam; % wavevector

Z = 1E6; % propagate one meter to the far-field
X = 0:2*pi/(L*dx):2*pi/dx-2*pi/(L*dx); % far-field transverse plain
X = Z*X/k_vec; % scaled appropriatly

for i = 1:length(z) % propagate to the far-field with Hankel functions
    Pol_HHG_stat = (EIR.*sqrt(I_z(end))).^qeff.*exp(1i*(alpha_long*I_max*I_z(end)*abs(EIR).^2+q*CEP(end)))+ (EIR.*sqrt(I_z(end))).^qeff.*exp(1i*(alpha_short*I_max*I_z(end)*abs(EIR).^2+q*CEP(end)));
    Pol_HHG_move = (EIR.*sqrt(I_z(i))).^qeff.*exp(1i*(alpha_long*I_max*I_z(i)*abs(EIR).^2+q*CEP(i)))+ (EIR.*sqrt(I_z(i))).^qeff.*exp(1i*(alpha_short*I_max*I_z(i)*abs(EIR).^2+q*CEP(i)));
    
    [Two_targ(i,:),kern] = ht(Pol_HHG_stat+Pol_HHG_move); % two target
    [One_targ(i,:),kern] = ht(Pol_HHG_move); % just moving target
    
end
%
mesh(z*1E-3,X/1E3,abs(Two_targ'))
view(2)
ylim([0 25])
xlim(1E-3*[min(z) max(z)])
ylabel('X (mm)')
xlabel('Z (mm)')
title(['Sqrt(Harmonic Intensity); q=' num2str(q)])
t=toc